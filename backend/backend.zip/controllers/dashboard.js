
const dashboard = (req, res) => {
    res.status(200).json({ message: "dashboard" });
    
  };


  module.exports = dashboard;
  